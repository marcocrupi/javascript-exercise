# Dom Tree - Exercise 5
Implementare il codice necessario per creare una tabella le cui righe sono generate dinamicamente.
Al click del pulsante "Add Row" occorre richiamare la funzione `addRow`, la quale si occupa di creare dinamicamente un elemento `<tr>` contenente un campo di testo per ciascuna colonna: `firstName`, `lastName` e `age`. Appendere la riga generata al `<tbody>` della tabella.