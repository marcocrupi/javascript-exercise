# Destructuring assignment - Exercise 2
Utilizzare la destrutturazione per eseguire l'assegnazione dei valori tramite un'unica linea di codice