# Array Methods - Exercise 2

Implementare la funzione `nicknameMap` che, dato un array di persone, crea un array di nickname. Il nickname deve essere formato in questa modo: `<name>-<age>`.

Esempio:

```
{ name: 'Paul', age: 21 } => Paul-21
```
