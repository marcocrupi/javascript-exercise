# Error handling - Exercise 3
Sostituire il lancio delle eccezioni con due classi custom che estendono dalla classe `Error`:

* `NegativeAmountError`: classe custom qualora viene fornito un importo negativo
* `WithdrawNotPermittedError`: classe custom qualora si cerca di ritirare dal proprio conto corrente un importo maggiore rispetto al totale consentito