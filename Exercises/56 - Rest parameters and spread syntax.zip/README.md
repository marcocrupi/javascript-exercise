# Rest parameters and spread syntax - Exercise 4
Come migliorare il codice affinché si eviti di specificare ad uno a uno i valori da passare alla funzione `sum`?