# Async Management - Exercise 2
Migliorare la funzione `fetchPersonById`, in modo tale che la `Promise` venga rigettata qualora non esiste una persona con l'id passato come parametro.