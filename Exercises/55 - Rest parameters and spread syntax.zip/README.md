# Rest parameters and spread syntax - Exercise 3
Come mergiare il valore di `newNumber` all'interno di `numberStore` senza utilizzare il metodo `push`?