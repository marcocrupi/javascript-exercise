# Classes - Exercise 3
Definire all'interno della classe `Person` un metodo statico che, dato in input un object literal, istanzia un oggetto `Person`.