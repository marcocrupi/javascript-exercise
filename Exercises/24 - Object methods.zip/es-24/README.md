# Object Methods - Exercise 2

Utilizzando l'oggetto `person` stampare in console i suoi valori, provando ad utilizzare il metodo `Object.values`:

```
Mario
Rossi
25
```
