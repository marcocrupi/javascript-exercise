# Dom Tree - Exercise 2
Implementare il codice necessario per recuperare il contenuto del primo campo di testo e stamparlo in console.
N.B: utilizzare la classe come selettore