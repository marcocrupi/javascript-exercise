const students = ['Paul', 'George', 'Lucas'];

function addStudent(student) {
  // ...
}

addStudent('Marco');
console.log(students);