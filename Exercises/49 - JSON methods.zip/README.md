# JSON methods - Exercise 1
Implementare il codice necessario per convertire l'oggetto `developer` in un json.