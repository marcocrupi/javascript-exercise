# Browser Storing Data - Exercise 2
Implementare il codice necessario per:
* Recuperare il post presente all'interno del LocalStorage (salvato tramite l'esercizio precedente)
* Visualizzare all'interno dell'elemento `#post-title` il titolo del post recuperato dal LocalStorage