# Network Requests - Exercise 2
Implementare il codice necessario per recuperare tramite una richiesta HTTP il todo con id 4 tramite il seguente url: https://jsonplaceholder.typicode.com/todos/4. Successivamente creare due elementi:
* Un elemento `<h2>` contenente il titolo del todo (proprietà `title`)
* Un elemento `<input type="checkbox">` con la proprietà `checked` impostata al valore presente per la proprietà `completed` del todo

Appendere all'interno del container i due elementi precedentemente creati.