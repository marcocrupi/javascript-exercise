# Destructuring assignment - Exercise 5
La destrutturazione restituisce `undefined` per le proprietà: `name`, `surname` e `old`.
Sai sistemare il codice affinché, pur mantenendo gli stessi nomi di proprietà per l'oggetto `person`, posso eseguire una rinominazione in fase di destrutturazione?