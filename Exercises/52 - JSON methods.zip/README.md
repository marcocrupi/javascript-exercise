# JSON methods - Exercise 4
In questo esercizio occorre filtrare le proprietà dell'oggetto `person` affinché vengono codificate in json solo i valori numerici (vale a dire `id` e `age`).