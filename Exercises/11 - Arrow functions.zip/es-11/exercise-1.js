const sum = function (a, b) {
  return a + b;
}

const log = function (value) {
  console.log(value);
}

log(sum(2, 5));