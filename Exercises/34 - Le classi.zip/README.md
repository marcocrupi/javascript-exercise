# Classes - Exercise 1
Definire la classe `Person` che accetta due parametri nel costruttore `firstName` e `lastName`