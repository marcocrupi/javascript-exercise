# JSON methods - Exercise 2
Implementare il metodo `fromJson` che accetta un json e istanzia un oggetto di tipo `Person`