# Object Copying - Exercise 2

In questo esercizio si desidera creare una copia esatta di `person1` e assegnarla alla variabile `person2`, permettendo così di modificare il `firstName` di `person2`, senza che venga modificato anche il valore `firstName` di `person1`
