const person = {
  // ...
}

console.log(john.fullName()); // John Doe
console.log(simon.fullName()); // Simon Collins