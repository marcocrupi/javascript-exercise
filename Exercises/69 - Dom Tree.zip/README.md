# Dom Tree - Exercise 1
Implementare il codice necessario per recuperare il contenuto del campo di testo `firstName` e stamparlo in console.
N.B: utilizzare l'id come selettore